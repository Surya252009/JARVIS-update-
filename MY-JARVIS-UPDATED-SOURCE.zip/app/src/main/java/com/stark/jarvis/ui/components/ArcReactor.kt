package com.stark.jarvis.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.stark.jarvis.ui.theme.JarvisCyan
import com.stark.jarvis.ui.theme.JarvisElectricBlue

enum class ReactorState {
    IDLE, LISTENING, PROCESSING, SPEAKING
}

@Composable
fun ArcReactor(
    modifier: Modifier = Modifier,
    state: ReactorState = ReactorState.IDLE,
    size: Int = 220
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ArcReactorRotation")

    val outerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(24000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outer"
    )

    val innerRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "inner"
    )

    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    ReactorState.LISTENING -> 600
                    ReactorState.PROCESSING -> 400
                    ReactorState.SPEAKING -> 800
                    ReactorState.IDLE -> 2400
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = modifier.size(size.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size.dp)) {
            val center = Offset(size.toDp().toPx() / 2, size.toDp().toPx() / 2)
            val radius = size.toDp().toPx() / 2 - 20

            // Outer ring
            rotate(outerRotation, pivot = center) {
                drawCircle(
                    color = JarvisCyan.copy(alpha = 0.3f),
                    radius = radius,
                    style = Stroke(width = 2.dp.toPx())
                )
                // 10 Segments
                for (i in 0 until 10) {
                    val angle = i * 36f
                    drawArc(
                        color = JarvisCyan,
                        startAngle = angle,
                        sweepAngle = 18f,
                        useCenter = false,
                        style = Stroke(width = 4.dp.toPx())
                    )
                }
            }

            // Inner counter-rotating ring
            rotate(innerRotation, pivot = center) {
                drawCircle(
                    color = JarvisElectricBlue.copy(alpha = 0.5f),
                    radius = radius * 0.65f,
                    style = Stroke(width = 3.dp.toPx())
                )
                for (i in 0 until 6) {
                    val angle = i * 60f
                    drawArc(
                        color = JarvisElectricBlue,
                        startAngle = angle,
                        sweepAngle = 30f,
                        useCenter = false,
                        style = Stroke(width = 5.dp.toPx())
                    )
                }
            }

            // Core energy center
            val coreGlow = Brush.radialGradient(
                colors = listOf(
                    JarvisCyan.copy(alpha = 0.9f),
                    JarvisElectricBlue.copy(alpha = 0.4f),
                    Color.Transparent
                ),
                center = center,
                radius = radius * 0.4f * pulse
            )
            drawCircle(brush = coreGlow, radius = radius * 0.45f * pulse)
        }
    }
}
