package com.stark.jarvis.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.stark.jarvis.data.local.JarvisApiSettings
import com.stark.jarvis.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var apiKey by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisBlack)
            .padding(24.dp)
    ) {
        Text("SYSTEM SETTINGS & CLOUD BRIDGES", color = JarvisCyan, style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(20.dp))

        Text("Gemini AI / OpenJarvis Backend", color = JarvisCyan, style = MaterialTheme.typography.titleMedium)
        Text("Backend URL", color = JarvisTextPrimary)
        Text("https://openjarvis-server-w8pi.onrender.com", color = JarvisTextSecondary)
        Spacer(modifier = Modifier.height(14.dp))
        Text("Render OPENJARVIS_API_KEY", color = JarvisTextPrimary)
        OutlinedTextField(
            value = apiKey,
            onValueChange = { apiKey = it; saved = false },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Paste your server API key") },
            singleLine = true,
            visualTransformation = if (showKey) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = JarvisCyan,
                unfocusedBorderColor = JarvisSurfaceBorder,
                focusedTextColor = JarvisTextPrimary,
                unfocusedTextColor = JarvisTextPrimary
            )
        )
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Checkbox(checked = showKey, onCheckedChange = { showKey = it })
            Text("Show key", color = JarvisTextSecondary)
        }
        Button(
            onClick = {
                scope.launch {
                    JarvisApiSettings.saveApiKey(context, apiKey)
                    apiKey = ""
                    saved = true
                }
            },
            enabled = apiKey.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan, contentColor = JarvisBlack)
        ) { Text("Save backend key") }
        if (saved) Text("Backend key saved on this device.", color = JarvisCyan)
        Spacer(modifier = Modifier.height(12.dp))
        Text("Your key is stored in this app's private device storage. Never share it publicly or commit it to GitHub.", color = JarvisTextSecondary)

        Spacer(modifier = Modifier.height(28.dp))
        Text("Amazon Alexa Smart Home Skill", color = JarvisCyan, style = MaterialTheme.typography.titleMedium)
        Text("Account Linking Status: NOT LINKED", color = JarvisTextPrimary)
        Text("Alexa OAuth and the Smart Home skill still need a separate integration. This screen cannot link an account or control devices yet.", color = JarvisTextSecondary)
    }
}
