package com.stark.jarvis.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.stark.jarvis.ui.components.ArcReactor
import com.stark.jarvis.ui.components.ReactorState
import com.stark.jarvis.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DashboardScreen(navController: NavController) {
    var currentTime by remember { mutableStateOf("") }
    var currentDate by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        while (true) {
            val now = Date()
            currentTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(now)
            currentDate = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(now)
            kotlinx.coroutines.delay(1000)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisBlack)
            .padding(24.dp)
    ) {
        // Top HUD Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "J.A.R.V.I.S. INTERFACE",
                    style = MaterialTheme.typography.headlineMedium,
                    color = JarvisCyan
                )
                Text(
                    text = "Assistant dashboard ready. Live services require configuration.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = JarvisTextSecondary
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(text = currentTime, style = MaterialTheme.typography.titleLarge, color = JarvisCyan)
                Text(text = currentDate, style = MaterialTheme.typography.bodySmall, color = JarvisTextSecondary)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Main Holographic Layout
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Left Column: Central Arc Reactor & Telemetry
            Box(
                modifier = Modifier
                    .weight(1.3f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(16.dp))
                    .background(JarvisSurface)
                    .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(16.dp))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    ArcReactor(state = ReactorState.IDLE, size = 260)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("CORE: READY", color = JarvisCyan, style = MaterialTheme.typography.titleMedium)
                    Text("AI STATUS: NOT VERIFIED", color = JarvisTextSecondary, style = MaterialTheme.typography.bodySmall)
                }
            }

            // Right Column: System Status Panels
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Connectivity Matrix
                StatusCard(title = "SYSTEM STATUS") {
                    StatusRow(label = "Gemini Cloud Brain", value = "CONFIGURE BACKEND", isPositive = false)
                    StatusRow(label = "OpenJarvis Connector", value = "NOT CONNECTED", isPositive = false)
                    StatusRow(label = "Alexa Skill Gateway", value = "NOT LINKED", isPositive = false)
                    StatusRow(label = "Smart Home Devices", value = "NO DEVICES LINKED", isPositive = false)
                }

                // Quick Tactical Actions
                StatusCard(title = "QUICK DIRECTIVES") {
                    Button(
                        onClick = { navController.navigate("voice") },
                        colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan.copy(alpha = 0.2f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = null, tint = JarvisCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Engage Voice Assistant", color = JarvisCyan)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { navController.navigate("smarthome") },
                        colors = ButtonDefaults.buttonColors(containerColor = JarvisElectricBlue.copy(alpha = 0.2f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Home, contentDescription = null, tint = JarvisElectricBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Manage Smart Facility", color = JarvisElectricBlue)
                    }
                }
            }
        }
    }
}

@Composable
fun StatusCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = JarvisSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = title, color = JarvisCyan, style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
fun StatusRow(label: String, value: String, isPositive: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = JarvisTextPrimary, style = MaterialTheme.typography.bodyMedium)
        Text(
            text = value,
            color = if (isPositive) JarvisSuccess else JarvisAlert,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}
