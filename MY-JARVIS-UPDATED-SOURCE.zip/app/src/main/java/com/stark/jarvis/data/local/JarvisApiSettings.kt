package com.stark.jarvis.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

private val Context.jarvisDataStore by preferencesDataStore(name = "jarvis_settings")

object JarvisApiSettings {
    private val apiKeyPreference = stringPreferencesKey("openjarvis_api_key")

    suspend fun saveApiKey(context: Context, apiKey: String) {
        context.jarvisDataStore.edit { preferences ->
            preferences[apiKeyPreference] = apiKey.trim()
        }
    }

    suspend fun getApiKey(context: Context): String {
        return context.jarvisDataStore.data.first()[apiKeyPreference].orEmpty()
    }
}
