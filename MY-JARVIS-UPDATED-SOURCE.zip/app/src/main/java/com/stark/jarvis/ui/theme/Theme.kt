package com.stark.jarvis.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = JarvisCyan,
    secondary = JarvisElectricBlue,
    background = JarvisBlack,
    surface = JarvisSurface,
    onPrimary = JarvisBlack,
    onBackground = JarvisTextPrimary,
    onSurface = JarvisTextPrimary
)

@Composable
fun JARVISTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
