package com.stark.jarvis.data.repository

import android.content.Context
import com.stark.jarvis.BuildConfig
import com.stark.jarvis.data.local.JarvisApiSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiRepository(private val context: Context) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    suspend fun generateResponse(prompt: String): String = withContext(Dispatchers.IO) {
        try {
            val apiKey = JarvisApiSettings.getApiKey(context)
            if (apiKey.isBlank()) {
                return@withContext "JARVIS setup required: Open Settings and save your Render OPENJARVIS_API_KEY first."
            }

            val baseUrl = BuildConfig.JARVIS_API_BASE_URL.trimEnd('/')
            val messages = JSONArray().put(
                JSONObject().put("role", "user").put("content", prompt)
            )
            val payload = JSONObject()
                .put("model", "gemini-2.5-flash")
                .put("messages", messages)
                .put("stream", false)
                .toString()

            val request = Request.Builder()
                .url("$baseUrl/v1/chat/completions")
                .header("Authorization", "Bearer $apiKey")
                .header("Accept", "application/json")
                .post(payload.toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val responseText = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = runCatching {
                        JSONObject(responseText).optString("detail").ifBlank { responseText }
                    }.getOrDefault(responseText)
                    throw IllegalStateException("Backend HTTP ${response.code}: ${detail.take(300)}")
                }
                val root = JSONObject(responseText)
                val reply = root.optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
                    ?.optString("content")
                    .orEmpty()
                if (reply.isBlank()) throw IllegalStateException("Backend returned an empty reply.")
                reply
            }
        } catch (error: Exception) {
            "JARVIS connection error: ${error.localizedMessage ?: "Unknown error"}"
        }
    }
}
