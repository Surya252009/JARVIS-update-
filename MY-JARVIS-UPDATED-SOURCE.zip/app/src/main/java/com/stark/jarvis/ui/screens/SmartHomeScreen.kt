package com.stark.jarvis.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.stark.jarvis.ui.theme.*

data class DeviceItem(val id: String, val name: String, val room: String, var isOn: Boolean)

@Composable
fun SmartHomeScreen() {
    var devices by remember { mutableStateOf(emptyList<DeviceItem>()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisBlack)
            .padding(24.dp)
    ) {
        Text("SMART FACILITY CONTROL", color = JarvisCyan, style = MaterialTheme.typography.headlineMedium)
        Text("No smart-home provider is connected. Device controls will appear after a real integration is configured.", color = JarvisTextSecondary)
        Spacer(modifier = Modifier.height(20.dp))

        if (devices.isEmpty()) {
            Text("No devices connected", color = JarvisTextPrimary, style = MaterialTheme.typography.titleMedium)
            Text("Connect a supported provider such as Alexa Smart Home or Home Assistant before sending commands.", color = JarvisTextSecondary)
        } else LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 240.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(devices) { device ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(JarvisSurface)
                        .border(1.dp, if (device.isOn) JarvisCyan.copy(alpha = 0.5f) else JarvisSurfaceBorder, RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Column {
                        Text(device.name, color = JarvisTextPrimary, style = MaterialTheme.typography.titleMedium)
                        Text(device.room, color = JarvisTextSecondary, style = MaterialTheme.typography.bodySmall)
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                if (device.isOn) "ACTIVE" else "OFFLINE",
                                color = if (device.isOn) JarvisSuccess else JarvisTextSecondary
                            )
                            Switch(
                                checked = device.isOn,
                                onCheckedChange = { newState ->
                                    devices = devices.map { if (it.id == device.id) it.copy(isOn = newState) else it }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = JarvisCyan,
                                    checkedTrackColor = JarvisCyan.copy(alpha = 0.3f)
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
